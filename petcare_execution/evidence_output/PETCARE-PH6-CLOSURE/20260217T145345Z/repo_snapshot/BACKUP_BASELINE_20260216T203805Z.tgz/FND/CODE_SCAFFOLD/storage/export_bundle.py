from typing import Dict, Any
from datetime import datetime

def build_export_bundle(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "exported_at": datetime.utcnow().isoformat(),
        "payload": payload,
    }
