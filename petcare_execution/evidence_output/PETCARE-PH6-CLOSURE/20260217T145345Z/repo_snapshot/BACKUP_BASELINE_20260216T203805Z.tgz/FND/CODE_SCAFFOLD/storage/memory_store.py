from typing import Dict, Any, List
from FND.CODE_SCAFFOLD.interfaces.storage_interface import StorageInterface

class MemoryStore(StorageInterface):
    def __init__(self) -> None:
        self._data: Dict[str, Dict[str, Any]] = {}

    def save(self, key: str, data: Dict[str, Any]) -> None:
        self._data[key] = data

    def get(self, key: str) -> Dict[str, Any] | None:
        return self._data.get(key)

    def list_keys(self) -> List[str]:
        return list(self._data.keys())
