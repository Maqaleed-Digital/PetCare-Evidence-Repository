from abc import ABC, abstractmethod
from typing import Any, Dict, List

class StorageInterface(ABC):
    @abstractmethod
    def save(self, key: str, data: Dict[str, Any]) -> None:
        pass

    @abstractmethod
    def get(self, key: str) -> Dict[str, Any] | None:
        pass

    @abstractmethod
    def list_keys(self) -> List[str]:
        pass
