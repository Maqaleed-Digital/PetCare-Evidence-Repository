from FND.CODE_SCAFFOLD.api.routes_platform_admin import health_check

def app():
    return health_check()

if __name__ == "__main__":
    print(app())
